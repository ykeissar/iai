import sys
from Agents import Agent, saboAct
from graphTools import getAbstract

global blocked
global L
L = 4

def main():
    f = open("params.txt", "r")
    flines = list(map(lambda x: x.replace('\n','').split(),f.readlines()))
    n = int(flines[0][1])
    deadLine = float(flines[1][1])
    cDeadLine = deadLine
    graph = {}
    j=2
    totalNumOfPpl = 0
    for i in range(2,2+n):
        ppl = int(flines[i][1][1:]) if len(flines[i])>1 else 0
        graph[flines[i][0][1:]] = {
                "p": ppl,
                "e":[]
            }
        j = j+1
        totalNumOfPpl += ppl
    for i in range(j+1,len(flines)):
        v1 = "V"+flines[i][1] 
        v2 = "V"+flines[i][2]
        w = int(flines[i][3][1:])
        graph[v1]["e"].append({
                "v":v2,
                "w":w,
            }
        )
        graph[v2]["e"].append({
                    "v":v1,
                    "w":w,
                }
        )
    print(graph)
    print("please enter number of agents:")
    num_of_agents = int(input())
    print ("please enter agents details: ")
    agents_details = input().split(',')
    agentDetails = list(map(lambda x: x.split(' '), agents_details))
        
    agentsList = list()
    for i in range(0,num_of_agents):
        agentsList.append(Agent(agentDetails[i][0], agentDetails[i][1],len(graph),L))
    agentsList[0].otherPos = agentDetails[1][1]
    agentsList[1].otherPos = agentDetails[0][1]

    # main loop
    print("Agents: \n",agentsList)
    print("Graph: \n",graph)
    time = 0
    while deadLine>0 and totalNumOfPpl>0 and not allTerminated(agentsList):
        # print('----------------###### time ######----------------',time,'numOfPeople - ',totalNumOfPpl)

        time += 1
        for index,i in enumerate(agentsList):
            if i.terminated:
                continue
            elif i.stepsLeft > 0:
                i.stepsLeft -= 1
            elif i.calcTime > 0:
                i.calcTime -= 1
            elif i.type == 's':
                saboAct(i,graph)
            else:
			    # we reached vertice, evacuating ppl
                verPpl = graph[i.currentPosition]["p"]
                totalNumOfPpl -= verPpl
                i.peopleEvacuated += verPpl
                graph[i.currentPosition]["p"] = 0
                if totalNumOfPpl == 0:
                    break
                #finding next vertice to travel
                prevVer = i.currentPosition
                i.currentPosition = getNextStep(i,graph)

                # print("Next step: ",i.currminimaxSteptPosition)
                if not i.currentPosition:
                    i.terminated = True
                else:
                    agentsList[1 if index == 0 else 0].otherPos = i.currentPosition
                    i.stepsLeft = getEdgeWeight(graph,prevVer,i.currentPosition)
                print('Agnet',index,'next step - ',i.currentPosition,', ',i.stepsLeft,'steps left')
                # print('Graph:\n',graph)
                i.numOfActions +=1
        deadLine -= 1
    feedback = "Well Done!!! \nAgents:\n"
    if agentsList[0].peopleEvacuated == 0:
        feedback = "Too Bad.. You could've done better, "
    print(feedback,'Agent',0,'type',agentsList[0].type,"evacuated ",agentsList[0].peopleEvacuated,'\nAgent',1,'type',agentsList[1].type,"evacuated ",agentsList[1].peopleEvacuated," \nAnd it took ",cDeadLine-deadLine," rounds.")

def allTerminated(agentsList):
    for i in agentsList:
    	if not i.terminated:
    		return False	
    return True	

def getEdgeWeight(graph,v1,v2):
    for e in graph[v1]['e']:
        if e['v'] == v2:
            return e['w']
    return -1

def getNextStep(agent,graph):
    if agent.type == 'h':
        return agent.humanStep(graph)
    elif agent.type == 'g':
        return agent.greedyStep(graph)
    elif agent.type[0] == 'm':
        return agent.minimaxStep(graph)
    else:
        return agent.getAstarStep(graph)
    return None

if __name__ == "__main__":
    main()